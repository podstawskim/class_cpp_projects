#ifndef UTILS_H
#define UTILS_H

#include "utils_global.h"

class UTILS_EXPORT Utils
{
public:
    Utils();

    int add(int a, int b);
};

#endif // UTILS_H
